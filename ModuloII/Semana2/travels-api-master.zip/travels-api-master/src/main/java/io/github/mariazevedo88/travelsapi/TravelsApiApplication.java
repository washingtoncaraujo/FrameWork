package io.github.mariazevedo88.travelsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelsApiApplication.class, args);
	}

}
