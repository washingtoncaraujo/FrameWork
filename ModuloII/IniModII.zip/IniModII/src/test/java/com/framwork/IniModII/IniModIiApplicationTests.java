package com.framwork.IniModII;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IniModIiApplicationTests {

	@Test
	void contextLoads() {
	}

}
